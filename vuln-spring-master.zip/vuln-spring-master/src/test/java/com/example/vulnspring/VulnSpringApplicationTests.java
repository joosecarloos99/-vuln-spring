package com.example.vulnspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VulnSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
